
# Ihre Loesung fuer Aufgabe 16


# TODO


print(find_palindrome())