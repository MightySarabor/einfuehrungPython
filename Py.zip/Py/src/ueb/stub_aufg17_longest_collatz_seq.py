
# Ihre Loesung fuer Aufgabe 17

# laengste Kette kleiner k
def collatz(k): 

# TODO

l,n=collatz(3)
print('Laenge:',l,' beginnend bei ',n)


