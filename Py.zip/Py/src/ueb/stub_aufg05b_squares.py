
# Ihre Loesung fuer Aufgabe 5b

# liefert alle Quadratzahlen zwischen x und y
def squares(x,y):

# TODO

squares(100,200)
squares(9,24)
squares(0,10)
squares(99,99)