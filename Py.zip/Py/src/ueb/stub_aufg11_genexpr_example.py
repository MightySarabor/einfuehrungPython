
# Ihre Loesung fuer Aufgabe 11

# Aufgabe 11a

# NEU: Fortsetzen der Zeile 

text='Python is a programming language that lets you ' + \
    'work more quickly and integrate your systems more effectively. ' + \
    'You can learn to use Python and see almost immediate gains in ' + \
    'productivity and lower maintenance costs. Python runs on Windows, ' + \
    'Linux/Unix, Mac OS X, and has been ported to the Java and .NET' + \
    'virtual machines. Python is free to use, even for commercial ' + \
    'products, because of its OSI-approved open source license.'

# TODO




# Aufgabe 11b

# TODO





