
# Ihre Loesung fuer Aufgabe 15

import unittest
import ueb.aufg10_valid_brackets as candidate

# Testfaelle fuer candidate
class Test_valid_brackets(unittest.TestCase):
    
    #
    def test_1(self):
     
    
        
        
        