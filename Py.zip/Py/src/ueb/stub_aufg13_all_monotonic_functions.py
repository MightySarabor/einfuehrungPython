

# Ihre Loesung fuer Aufgabe 13

def all_monotonic_functions(m,k):

# TODO


all_monotonic_functions(2,3)
all_monotonic_functions(3,2)
all_monotonic_functions(5,6)

