
# Ihre Loesung fuer Aufgabe 3

# alle Elemente in exakt zwei der drei Mengen
def two_in_three(A,B,C):

# TODO
    
two_in_three({1,2,'a'},{2,'b',0},{3,'a'})
two_in_three(set(),{1,'one','two'},{1,'one'})





