
# Ihre Loesung fuer Aufgabe 6

# fuegt number der Liste contacts[name] hinzu 
def add_number(contacts, name, number):

# TODO


my_contacts = {}
add_number(my_contacts, 'Hugo', 4711)
add_number(my_contacts, 'Lisa', 1920)
add_number(my_contacts, 'Hugo', 4712)
add_number(my_contacts, 'Hugo', 4711)
