
# Ihre Loesung fuer Aufgabe 4

# naiver Primzahltest für m>=2
def prime(m):

# TODO


for m in range(2,100):
    if prime(m): print(m)

prime(3203431780337)


