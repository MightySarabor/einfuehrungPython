
# Ihre Loesung fuer Aufgabe 2

# liefert maximales gemeinsames Praefix
def common_prefix(v,w):
    
# TODO
    
    
common_prefix('abcdef', 'ab12')
common_prefix('b', 'ab12')
common_prefix('bcd', 'bccd')




