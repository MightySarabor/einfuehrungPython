
# Ihre Loesung fuer Aufgabe 8

from ueb.aufg07_d import d

# Vergleich aller Paare, #U >= 2
def closest_pair(U):

# TODO



U1 = {(12,4),(2,17),(3,3)}
print(closest_pair(U1))

U2 = {(2,2), (3,4), (5,4)}
print(closest_pair(U2))


