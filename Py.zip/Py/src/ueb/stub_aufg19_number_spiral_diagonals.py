
# Ihre Loesung fuer Aufgabe 19


def spiral_sum(n):

# TODO

spiral_sum(5)       
spiral_sum(1001)    



