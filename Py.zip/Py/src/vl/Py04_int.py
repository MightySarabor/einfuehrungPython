

# 
x = 5
y = 3

x * y
x // y  # ganzz. Division ohne Nachkommastellen
x % y   # sowie Rest


# Kurzschreibweisen
x = y = 1           # Mehrfachzuweisungen in einer Zeile
x = 1; y = 2
x,y = 3,4

x += 3              # auch fuer -,*, //, %


# einzeilige zusammengesetzte Anweisungen
while (x>0): x-=1   

for i in range(2,5): print(i)

if (x==0): y = x


# Wertebereich ist nur durch den Speicher begrenzt
2**10000

