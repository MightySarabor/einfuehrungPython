
# Ihre Loesung fuer Aufgabe 1


# berechnet m-te Fibonacci-Zahl
# und gibt alle Vorgaenger aus
def fib(m):
   
# TODO



fib(0)
fib(1)
fib(10)
fib(28)

x = fib(10)