
# Ihre Loesung fuer Aufgabe 5a


# liefert alle Wortlaengen als Liste
def word_length(words):

# TODO

words = ['Der','Python-Vorkurs','ist','nicht','so','schlecht']
word_length(words)


