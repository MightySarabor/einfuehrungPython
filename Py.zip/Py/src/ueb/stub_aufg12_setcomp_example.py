
# Ihre Loesung fuer Aufgabe 12

# Aufgabe 12a
# TODO

# Aufgabe 12b
# TODO

