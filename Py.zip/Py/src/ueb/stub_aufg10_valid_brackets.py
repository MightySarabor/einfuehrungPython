
# Ihre Loesung fuer Aufgabe 10

# Klammerausdruecke pruefen 
def valid_brackets(w):

# TODO

w = '(a+1)*(2+7)//(2*(3+c)*2)'
valid_brackets(w)
w = '(a+b)(b+c)-1)'
valid_brackets(w)
w = '()()((())'
valid_brackets(w)



