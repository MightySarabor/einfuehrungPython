
# Ihre Loesung fuer Aufgabe 9

# Kantenmenge E fuer Digraphen und Kostensumme 
def edgeset_di(G):                   

# TODO

# Bsp-Digraph mit Kantenkosten
def define_G():
    G = [   {1:2, 2:4},
            {0:2, 2:5},
            {}
        ]
    return G

G = define_G()
E = edgeset_di(G)