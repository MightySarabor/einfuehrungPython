
# Ihre Loesung fuer Aufgabe 7

# Euklidische Distanz
def d(p,q):
# TODO


p = (4,7)
q = (5,3)
print(d(p,q))

p = (-12,7)
q = (5,-3)
print(d(p,q))
