
# Ihre Loesung fuer Aufgabe 14

from ueb.aufg08_closest_pair import closest_pair

# Testdaten erzeugen
#
from random import randrange
def rand_set(m):
    # TODO
    
U = rand_set(1000)
len(U)

print(closest_pair(U))



# Timer deklarieren
import timeit
# TODO


# Parameter fuer den Timer setzen
# TODO

# Messung
# TODO